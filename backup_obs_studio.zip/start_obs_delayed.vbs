WScript.Sleep 10000
Set objShell = CreateObject("WScript.Shell")
objShell.CurrentDirectory = "C:\Program Files\obs-studio\bin\64bit"
objShell.Run """C:\Program Files\obs-studio\bin\64bit\obs64.exe"" --startreplaybuffer --minimize-to-tray --disable-shutdown-check --disable-safe-mode --disable-missing-files", 1, False

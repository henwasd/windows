' Autostart do OBS (10s de atraso)
' - limpa a marca de "desligamento sujo" para nao abrir o aviso de Modo Seguro
' - usa apenas flags validas do OBS
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")
Set wmi = GetObject("winmgmts:\\.\root\cimv2")

Function ObsRunning()
    Dim procs
    Set procs = wmi.ExecQuery("SELECT ProcessId FROM Win32_Process WHERE Name='obs64.exe'")
    ObsRunning = (procs.Count > 0)
End Function

sentinel = sh.ExpandEnvironmentStrings("%APPDATA%") & "\obs-studio\.sentinel"

On Error Resume Next
If fso.FolderExists(sentinel) Then fso.DeleteFolder sentinel, True
If fso.FileExists(sentinel) Then fso.DeleteFile sentinel, True
On Error GoTo 0

WScript.Sleep 10000

If Not ObsRunning() Then
    sh.CurrentDirectory = "C:\Program Files\obs-studio\bin\64bit"
    sh.Run """C:\Program Files\obs-studio\bin\64bit\obs64.exe"" --startreplaybuffer --minimize-to-tray --disable-missing-files", 1, False
End If